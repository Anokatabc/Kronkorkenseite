<footer class="footer">
<div class="footer">
    <div class="toTopDiv"><a href="#" class="toTop">&emsp;&#32;<b>⇧</b> <br>   &emsp;Top</a></div>
<div class="footer-index">
    <div class="information">
        <div class="contact">
            <h3>Contact</h3>
            <p class="information-text">Phone Number:<br>☎ 123/456789</p><br>
            <p class="information-text">For Business Inquiries:<br>✉ max.mustermann@beispiel.de</p><br>
        </div>
        <div class="location">
            <h3>Location</h3>
            <p class="location-text">🌍 Heidelberg-Wieblingen 69123</p>
            <div class="bottom-footer">
                <div class="copyright"><p class="copyright-text">Ⓒ 2025 Julian Voigt. All rights reserved.</p></div>
                <div class="decoration"></div>
            </div>
        </div>        
            
    </div>    
    
</div>
    <script src="public/js/script.js"></script>
    </div>
</footer>